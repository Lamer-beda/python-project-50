### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lamer-beda/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lamer-beda/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3845c9a3b37f789cfc11/maintainability)](https://codeclimate.com/github/Lamer-beda/python-project-50/maintainability)
